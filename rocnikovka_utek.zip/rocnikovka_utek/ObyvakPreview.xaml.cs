using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace rocnikovka_utek
{
    public partial class ObyvakPreview : Window
    {
        public ObyvakPreview()
        {
            InitializeComponent();

            PreviewImage.Source = new BitmapImage(new System.Uri("pack://application:,,,/Images/obyvak.png"));
            this.Loaded += (s, e) => DrawGrid();
        }

        private void DrawGrid()
        {
            GridCanvas.Children.Clear();
            double step = 50;
            double w = PreviewImage.ActualWidth;
            double h = PreviewImage.ActualHeight;
            if (w == 0 || h == 0)
            {
                return;
            }

            for (double x = 0; x < w; x += step)
            {
                var line = new System.Windows.Shapes.Line
                {
                    X1 = x,
                    Y1 = 0,
                    X2 = x,
                    Y2 = h,
                    Stroke = Brushes.Red,
                    StrokeThickness = 0.8,
                    Opacity = 0.6
                };
                GridCanvas.Children.Add(line);
            }

            for (double y = 0; y < h; y += step)
            {
                var line = new System.Windows.Shapes.Line
                {
                    X1 = 0,
                    Y1 = y,
                    X2 = w,
                    Y2 = y,
                    Stroke = Brushes.Red,
                    StrokeThickness = 0.8,
                    Opacity = 0.6
                };
                GridCanvas.Children.Add(line);
            }

            GridCanvas.IsHitTestVisible = false;
        }

        private void ToggleGridButton_Click(object sender, RoutedEventArgs e)
        {
            GridCanvas.Visibility = GridCanvas.Visibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}