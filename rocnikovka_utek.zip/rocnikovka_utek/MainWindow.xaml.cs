﻿using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace rocnikovka_utek
{
    public partial class MainWindow : Window
    {
        BitmapImage menu;
        BitmapImage obyvak;
        BitmapImage pokoj;

        int stav = 0;

        // inventory
        System.Collections.ObjectModel.ObservableCollection<string> inventory =
            new System.Collections.ObjectModel.ObservableCollection<string>();

        // selection for moving hotspots
        private FrameworkElement selectedHotspot = null;
        private System.Windows.Shapes.Rectangle selectionRect = null;

        // TIMER PRO POKOJ
        DispatcherTimer pokojTimer = new DispatcherTimer();
        // Backstory overlay timer
        private DispatcherTimer backstoryTimer = new DispatcherTimer();

        public MainWindow()
        {
            InitializeComponent();

            menu = new BitmapImage(new Uri("pack://application:,,,/Images/menu.png"));
            obyvak = new BitmapImage(new Uri("pack://application:,,,/Images/obyvak.png"));
            pokoj = new BitmapImage(new Uri("pack://application:,,,/Images/výkres.png"));

            MainImage.Source = menu;

            InventoryList.ItemsSource = inventory;

            this.PreviewKeyDown += MainWindow_PreviewKeyDown;
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (stav == 0)
            {
                Point p = e.GetPosition(this);
                double h = this.ActualHeight;

                if (p.Y > h * 0.4 && p.Y < h * 0.6)
                {
                    // Přepnutí obrázku
                    MainImage.Source = obyvak;
                    stav = 1;

                    // Zobraz backstory overlay. Hotspoty a inventář budou aktivovány po zavření overlay.
                    ShowBackstory("Jsme zloději a právě se snažíme vykrást byt. Během akce jsme zaslechli zvuk odemykání — musíme se dostat ven, ale přední dveře jsou zamčené. Hledej jinou cestu.");

                    NovaHraButton.Visibility = Visibility.Collapsed;
                    KonecButton.Visibility = Visibility.Collapsed;
                }

                if (p.Y > h * 0.75)
                {
                    Application.Current.Shutdown();
                }
            }
        }

        private void NovaHra_Click(object sender, RoutedEventArgs e)
        {
            if (stav == 0)
            {
                MainImage.Source = obyvak;
                stav = 1;

                ShowBackstory("Jsme zloději a právě se snažíme vykrást byt. Během akce jsme zaslechli zvuk odemykání — musíme se dostat ven, ale přední dveře jsou zamčené. Hledej jinou cestu.");

                NovaHraButton.Visibility = Visibility.Collapsed;
                KonecButton.Visibility = Visibility.Collapsed;
                BackToMenuButton.Visibility = Visibility.Collapsed;

                // MessageText zůstane prázdné do zavření overlayu
                MessageText.Text = string.Empty;
            }
        }

        private void ShowBackstory(string text)
        {
            BackstoryText.Text = text;
            BackstoryOverlay.Visibility = Visibility.Visible;

            // Nastav auto-skrýt po 6 sekundách pro plynulost hry
            backstoryTimer.Stop();
            backstoryTimer.Interval = TimeSpan.FromSeconds(6);
            backstoryTimer.Tick -= BackstoryTimer_Tick;
            backstoryTimer.Tick += BackstoryTimer_Tick;
            backstoryTimer.Start();
        }

        private void BackstoryTimer_Tick(object? sender, EventArgs e)
        {
            backstoryTimer.Stop();
            HideBackstory();
        }

        private void HideBackstory()
        {
            BackstoryOverlay.Visibility = Visibility.Collapsed;
            // Aktivuj hotspoty a inventář až po zavření overlayu
            HotspotCanvas.Visibility = Visibility.Visible;
            InventoryPanel.Visibility = Visibility.Visible;
            MessageText.Text = "Jsi v obýváku. Klikni na předměty pro interakci.";
        }

        private void BackstoryOverlay_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            backstoryTimer.Stop();
            HideBackstory();
        }

        private void Konec_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Hotspot_Item1_Click(object sender, RoutedEventArgs e)
        {
            string item = "Klíč";

            if (!inventory.Contains(item))
            {
                inventory.Add(item);
                MessageText.Text = "Našel jsi klíč a přidal jsi ho do inventáře.";
            }
            else
            {
                MessageText.Text = "Už tu nic není.";
            }
        }

        private void Hotspot_Item2_Click(object sender, RoutedEventArgs e)
        {
            MessageText.Text = "Ta káva je starší než já snad.";
        }

        private void Door_Wrong_Click(object sender, RoutedEventArgs e)
        {
            MessageText.Text = inventory.Contains("Klíč")
                ? "Špatná dírka/zámek."
                : "Smůla, dveře jsou zamčené.";
        }

        private void Door_Correct_Click(object sender, RoutedEventArgs e)
        {
            if (!inventory.Contains("Klíč"))
            {
                MessageText.Text = "Smůla, dveře jsou zamčené. Potřebuješ klíč.";
                return;
            }

            MessageText.Text = "Konečně! Vstupuji do pokoje.";
            MainImage.Source = pokoj;
            stav = 2;

            HotspotCanvas.Visibility = Visibility.Collapsed;
            InventoryPanel.Visibility = Visibility.Collapsed;

            // 🕒 TIMER 5 SEKUND
            pokojTimer = new DispatcherTimer();
            pokojTimer.Interval = TimeSpan.FromSeconds(5);
            pokojTimer.Tick += PokojTimer_Tick;
            pokojTimer.Start();
        }

        private void PokojTimer_Tick(object sender, EventArgs e)
        {
            pokojTimer.Stop();
            MessageText.Text = "…a hele, balkon. Teď to jen musím vypáčit.";

            // Po zobrazení výkresu odkryj speciální hotspoty (tyč a balkon)
            Hotspot_Stick.Visibility = Visibility.Visible;
            Hotspot_Balcony.Visibility = Visibility.Visible;

            // Skryj dveře, aby se v pokoji nezobrazovaly
            Door_Wrong.Visibility = Visibility.Collapsed;
            Door_Correct.Visibility = Visibility.Collapsed;

            // Zobraz také hotspoty specifické pro pokoj (koberec, postel)
            Hotspot_Pokoj_Carpet.Visibility = Visibility.Visible;
            Hotspot_Pokoj_Bed.Visibility = Visibility.Visible;

            // Zobraz canvas a inventář, aby hráč mohl s těmito hotspoty interagovat
            HotspotCanvas.Visibility = Visibility.Visible;
            InventoryPanel.Visibility = Visibility.Visible;
        }

        private void Hotspot_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
            SelectHotspot(sender as FrameworkElement);
        }

        private void SelectHotspot(FrameworkElement btn)
        {
            ClearSelectionRect();
            if (btn == null) return;

            selectedHotspot = btn;

            double w = (double.IsNaN(btn.Width) || btn.Width == 0)
                ? btn.ActualWidth : btn.Width;

            double h = (double.IsNaN(btn.Height) || btn.Height == 0)
                ? btn.ActualHeight : btn.Height;

            selectionRect = new System.Windows.Shapes.Rectangle
            {
                Width = w + 6,
                Height = h + 6,
                Stroke = System.Windows.Media.Brushes.Yellow,
                StrokeThickness = 2,
                RadiusX = 4,
                RadiusY = 4
            };

            double left = System.Windows.Controls.Canvas.GetLeft(btn);
            double top = System.Windows.Controls.Canvas.GetTop(btn);

            if (double.IsNaN(left)) left = 0;
            if (double.IsNaN(top)) top = 0;

            System.Windows.Controls.Canvas.SetLeft(selectionRect, left - 3);
            System.Windows.Controls.Canvas.SetTop(selectionRect, top - 3);

            HotspotCanvas.Children.Add(selectionRect);

            MessageText.Text =
                "Hotspot vybrán: klikni levým tlačítkem pro přesun nebo Esc pro zrušení.";
        }

        private void ClearSelectionRect()
        {
            if (selectionRect != null)
            {
                HotspotCanvas.Children.Remove(selectionRect);
                selectionRect = null;
            }

            selectedHotspot = null;
        }

        private void HotspotCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (selectedHotspot == null)
                return;

            Point p = e.GetPosition(HotspotCanvas);
            MoveHotspotTo(selectedHotspot, p.X, p.Y);

            MessageText.Text = "Hotspot přesunut.";
            ClearSelectionRect();
        }

        private void MoveHotspotTo(FrameworkElement btn, double x, double y)
        {
            double w = (double.IsNaN(btn.Width) || btn.Width == 0)
                ? btn.ActualWidth : btn.Width;

            double h = (double.IsNaN(btn.Height) || btn.Height == 0)
                ? btn.ActualHeight : btn.Height;

            double left = x - w / 2;
            double top = y - h / 2;

            System.Windows.Controls.Canvas.SetLeft(btn, left);
            System.Windows.Controls.Canvas.SetTop(btn, top);
        }

        private void MainWindow_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                ClearSelectionRect();
                MessageText.Text = "Přesouvání zrušeno.";
            }
        }

        private void Hotspot_Carpet_Click(object sender, RoutedEventArgs e)
        {
            MessageText.Text = "Prohledal jsi koberec... ale nic tu není. Jen prach.";
        }

        private void Hotspot_NoKey_Click(object sender, RoutedEventArgs e)
        {
            MessageText.Text = !inventory.Contains("Klíč")
                ? "Nemáš klíč. Tohle nejde otevřít."
                : "Máš klíč, ale tohle tady nepoužiješ.";
        }

        private void Hotspot_Stick_Click(object sender, RoutedEventArgs e)
        {
            if (!inventory.Contains("Dřevěná tyč"))
            {
                inventory.Add("Dřevěná tyč");
                MessageText.Text = "Helemese, tady je nějaká dřevěná tyč. Ta by se mohla hodit.";
            }
            else
            {
                MessageText.Text = "Tyč už máš.";
            }
        }

        private void Hotspot_Balcony_Click(object sender, RoutedEventArgs e)
        {
            if (!inventory.Contains("Dřevěná tyč"))
            {
                MessageText.Text = "Balkonové dveře jsou zaseknuté. Potřeboval bych něco na vypáčení.";
                return;
            }

            MessageText.Text = "Použil jsi dřevěnou tyč a dveře povolily.";

            MainImage.Source = new BitmapImage(
                new Uri("pack://application:,,,/Images/konec.png"));

            HotspotCanvas.Visibility = Visibility.Collapsed;
            InventoryPanel.Visibility = Visibility.Collapsed;

            // Zobraz tlačítko pro návrat do menu na konci
            BackToMenuButton.Visibility = Visibility.Visible;
        }

        private void BackToMenu_Click(object sender, RoutedEventArgs e)
        {
            // Přepni zpět do hlavního menu
            MainImage.Source = menu;
            stav = 0;

            // Skryj kontextové panely a uprav odkrytá tlačítka
            HotspotCanvas.Visibility = Visibility.Collapsed;
            InventoryPanel.Visibility = Visibility.Collapsed;

            NovaHraButton.Visibility = Visibility.Visible;
            KonecButton.Visibility = Visibility.Visible;
            BackToMenuButton.Visibility = Visibility.Collapsed;

            MessageText.Text = "Jsi zpět v hlavním menu.";
        }

        private void Hotspot_Pokoj_Carpet_Click(object sender, RoutedEventArgs e)
        {
            MessageText.Text = "Ten koberec má tady bordel... stejně bych tu nic neukradl.";
        }

        private void Hotspot_Pokoj_Bed_Click(object sender, RoutedEventArgs e)
        {
            MessageText.Text = "Postel vypadá pohodlně — dal bych si šlofíka.";
        }

    }
}

